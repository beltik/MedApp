//
//  VkontakteAPI.m
//  MadApp
//
//  Created by Necrosoft on 18/01/16.
//  Copyright © 2016 Necrosoft. All rights reserved.
//

#import "MedsolutionAPI.h"
#import "HTTPClient.h"
#import "NewsParseer.h"
#import "DetailNewsParseer.h"
#import "AFNetworking.h"
#import <Motis.h>


@interface MedsolutionAPI () {
    
    HTTPClient *httpClient;
}


@end

@implementation MedsolutionAPI

/* Стандартная реализация синглтона, которая гарантирует, что в один момент времени только один thread сможет иметь доступ к объекту для его инициализации. В памяти будет только один уникальный объект класса VkontakteAPI */

+ (MedsolutionAPI*)sharedInstance
{
    
    static MedsolutionAPI *_sharedInstance = nil;
    
    
    static dispatch_once_t oncePredicate;
    
    
    dispatch_once(&oncePredicate, ^{
        _sharedInstance = [[MedsolutionAPI alloc] init];
    });
    
    return _sharedInstance;
}

/* Инициализация класса. Мы так же инициализируем класс httpClient, отвечающий за взаимодействие с веб сервисом посредством ХТТП запросов. */

- (id)init
{
    self = [super init];
    if (self) {
        httpClient = [[HTTPClient alloc] init];

    }
    return self;
}

/* Получение новостей */

-(void)getNewsWithParameters:(NSDictionary *)parameters :(void (^)(NSMutableArray *))completionBlock{
    
    [httpClient getNewsWithParameters:parameters completion:^(id response) {
        
        /* Получаем массив по конкретному пути в объекте JSON */
        
        NSArray * array = [response valueForKey:@"data"];
        
        /*  Новый массив для хранения результатов */
        
        NSMutableArray *arrayNews = [[NSMutableArray alloc] init];
        
        /*  Цикл для заполнения массива объектами класса NewsParseer */
        
        for (int i = 0; i < array.count; i++) {
            
            /* Маппинг ответа */
            
            NewsParseer *news = [[NewsParseer alloc]init];
            
            /* Используем метод из сторонней библиотеки Motis для маппинга ответа */
            
            [news mts_setValuesForKeysWithDictionary:[array objectAtIndex:i]];
            
            /* Добавляем объект в массив */
            
            [arrayNews addObject:news];
            
            /* Если мы дошли до последнего элемента в массиве, то отправляем уведомление через центр уведомлений и передаем массив через блок */
            
            if ([[array objectAtIndex:i] isEqual:[array lastObject]]){
                
                completionBlock(arrayNews);
                [[NSNotificationCenter defaultCenter] postNotificationName:@"updateTable" object:self];
            }
            
        }

    }];

    
}

-(void)getNewsDetailWithID:(NSString *)itemID :(void (^)(NSMutableArray *))completionBlock{
    
    [httpClient getDetailOfNewsWithID:itemID completion:^(id response) {
        
        /* Парсим детали конкретной новости */
        
        /* Новый массив для хранения результатов */
        
        NSMutableArray *arrayNews = [[NSMutableArray alloc] init];
        
        /* Массив хранящий данные о детали конкретной новости */
        
        NSArray * detailedNews = [response valueForKey:@"data"];
        
        /* Маппинг ответа - объект хранящий детали конкретной новости */
        
        DetailNewsParseer *detailNews = [DetailNewsParseer new];
        
        [detailNews mts_setValuesForKeysWithDictionary:[detailedNews objectAtIndex:0]];
        
        /* Добавляем текущий объект в массив */
       
        [arrayNews addObject:detailNews];
        
        /* Маппинг ответа - массивы хранящие данные о spotlight */
        
        NSArray * spotlightDataArray = [response valueForKey:@"spotlight"];
        
        /* Цикл для заполнения массива похожих новостей объектами класса NewsParseer */
        
        for (int i=0; i<spotlightDataArray.count; i++) {
            
            NewsParseer *spotlightNews = [NewsParseer new];
            
            [spotlightNews mts_setValuesForKeysWithDictionary:[spotlightDataArray objectAtIndex:i]];
            
            [arrayNews addObject:spotlightNews];
            
            if ([[spotlightDataArray objectAtIndex:i] isEqual:[spotlightDataArray lastObject]]){
                
                /* Мы дошли до последнего элемента в массиве, отправляем уведомление через центр уведомлений и передаем массив через блок */
               
                completionBlock(arrayNews);
                [[NSNotificationCenter defaultCenter] postNotificationName:@"updateDetailTable" object:self];
            }
        }

    }];
}



















@end
