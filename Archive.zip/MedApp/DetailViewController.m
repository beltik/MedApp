//
//  DetailViewController.m
//  MedApp
//
//  Created by Necrosoft on 24/01/16.
//  Copyright © 2016 Necrosoft. All rights reserved.
//

#import "DetailViewController.h"
#import "MedsolutionAPI.h"
#import "UIImageView+AFNetworking.h"
#import "NewsParseer.h"
#import "DetailViewController.h"
#import "UIColor+JPExtras.h"
#import "MyCell.h"

/* Макросы для удобства получения высоты-ширины экрана */

#define SCREEN_WIDTH  [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height


@implementation DetailViewController {
    
    /* View, которой будет накладываться на основное вместе с индикатором загрузки, и отображаться пока данные с сервера загружаются. */

    UIView *viewToAdd;
    
    /* Индикатор активности загрузки */

    UIActivityIndicatorView *indicator;
    MyCell *cell;
    
    /* Булевая переменная, помгающая таблице определить, когда нужно загружать данные (получены они или нет) */

    BOOL isDataLoaded;
}

-(void)viewDidLoad{
    
    [self addActivityIndicatorWithView];
    
    self.spotlightTableView.dataSource = self;
    self.spotlightTableView.delegate = self;

    
    // Центр уведомлений. Подписываемся на уведомления чтобы знать, когда нужно обновить табличку.
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadingFinished:) name:@"updateDetailTable" object:nil];
    
    
    [[MedsolutionAPI sharedInstance] getNewsDetailWithID:[self detailNewsID] :^(NSMutableArray *dataArray) {
        
        self.detailDataArray = dataArray;
        NSLog(@"Data array? %@", self.detailDataArray);
    }];
    
    
    
;}

#pragma mark - Notification Center

-(void)loadingFinished: (NSNotification*) notification{
    
    NSLog(@"Recieved notify");
    
    /* Мы получили уведомление и можем убрать загрузочную вьюшку и индикатор */
    
    [self removeActivityIndicatorAndLoadingView];
    
    /* Определяем высоту UILabel, отображающего новости */
 
    [self adjustTextLabelSize];
    
    /* Добавляем элементы интерфейса программно */
    
    [self createUserInterface];

    /* Загружаем изображение */

    [self.detailImageView setImageWithURL:[NSURL URLWithString:self.detailUrlString]];
    
    /* Выставляем текст новости */

    self.detailTextLabel.text = [[self.detailDataArray objectAtIndex:0]valueForKey:@"text"];
    
    /* Выставляем дату создания новости */
    
    self.detailCreatedAtLabel.text = self.detailCreatedAt;
    
    /* Выставляем источник новости */

    self.detailSourceLabel.text = [[self.detailDataArray objectAtIndex:0]valueForKey:@"source"];
    
    /* Перезагружаем таблицу */
    
    isDataLoaded = YES;
    
    [self.spotlightTableView reloadData];
 


}

#pragma mark - UI

-(void)adjustTextLabelSize{
    
    CGSize maximumLabelSize = CGSizeMake(300, FLT_MAX);
    
    CGSize expectedLabelSize = [[[self.detailDataArray objectAtIndex:0]valueForKey:@"text"] sizeWithFont:[UIFont fontWithName:@"Helvetica Neue" size:15] constrainedToSize:maximumLabelSize lineBreakMode:self.detailTextLabel.lineBreakMode];
    
    
    /* Create detail text label */
    
    self.detailTextLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 360, 300, expectedLabelSize.height)];
    self.detailTextLabel.numberOfLines = 20;
    self.detailTextLabel.font = [UIFont fontWithName:@"Helvetica Neue" size:15];
    self.detailTextLabel.textAlignment = NSTextAlignmentLeft;
    
    
    [self.detailScrollView addSubview:self.detailTextLabel];
    
    
}

-(void)createUserInterface{
    
    /* Create UI */
    self.detailScrollView.backgroundColor = [UIColor whiteColor];
    
    /* Create ImageView */
    
    self.detailImageView =[[UIImageView alloc] initWithFrame:CGRectMake(10,10,300,300)];
    self.detailImageView.contentMode = UIViewContentModeScaleAspectFit;
    
    [self.detailImageView setImageWithURL:[NSURL URLWithString:self.detailUrlString]];
    
    [self.detailScrollView addSubview:self.detailImageView];
    
    /* Create detail text label header */
    
    UILabel *detailTextHeaderLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 320, 300, 30)];
    detailTextHeaderLabel.text = @"Текст новости:";
    detailTextHeaderLabel.font = [UIFont fontWithName:@"Helvetica Neue" size:15];
    detailTextHeaderLabel.textAlignment = NSTextAlignmentCenter;

    [self.detailScrollView addSubview:detailTextHeaderLabel];
    
    /* Create created at text label header */
    
    UILabel *createdAtTextLabelheader = [[UILabel alloc]initWithFrame:CGRectMake(10, 370 + self.detailTextLabel.frame.size.height, 300, 30)];
    createdAtTextLabelheader.text = @"Дата создания:";
    createdAtTextLabelheader.font = [UIFont fontWithName:@"Helvetica Neue" size:15];
    createdAtTextLabelheader.textAlignment = NSTextAlignmentCenter;
    [self.detailScrollView addSubview:createdAtTextLabelheader];
    
    /* Create created at text label */
    
    self.detailCreatedAtLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 410 + self.detailTextLabel.frame.size.height , 300, 30)];
    self.detailCreatedAtLabel.text = @"9 октября";
    self.detailCreatedAtLabel.font = [UIFont fontWithName:@"Helvetica Neue" size:15];
    self.detailCreatedAtLabel.textAlignment = NSTextAlignmentCenter;
    [self.detailScrollView addSubview:self.detailCreatedAtLabel];
    
    /* Create source text label header */
    
    UILabel *sourceHeaderTextLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 450 + self.detailTextLabel.frame.size.height, 300, 30)];
    sourceHeaderTextLabel.text = @"Источник:";
    sourceHeaderTextLabel.font = [UIFont fontWithName:@"Helvetica Neue" size:15];
    sourceHeaderTextLabel.textAlignment = NSTextAlignmentCenter;
    [self.detailScrollView addSubview:sourceHeaderTextLabel];
    
    /* Create source text label */
    self.detailSourceLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 490 + self.detailTextLabel.frame.size.height, 300, 30)];
    self.detailSourceLabel.text = @"http://anime.adult.ru";
    self.detailSourceLabel.font = [UIFont fontWithName:@"Helvetica Neue" size:15];
    self.detailSourceLabel.textAlignment = NSTextAlignmentCenter;
    [self.detailScrollView addSubview:self.detailSourceLabel];
    
    /* Create spotlight text label header */
    
    UILabel *spotlightLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 530 + self.detailTextLabel.frame.size.height, 300, 30)];
    spotlightLabel.text = @"Похожие новости:";
    spotlightLabel.font = [UIFont fontWithName:@"Helvetica Neue" size:15];
    spotlightLabel.textAlignment = NSTextAlignmentCenter;
    [self.detailScrollView addSubview:spotlightLabel];

    
    
    
    self.detailScrollView.contentSize = CGSizeMake(320,1040);
    
}

-(void)addActivityIndicatorWithView{
    
    // Добавляем View
    
    viewToAdd = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    viewToAdd.backgroundColor = [UIColor colorWithR:159 G:182 B:205 A:1];
    
    self.detailScrollView.scrollEnabled = NO;
    
    [self.detailScrollView addSubview:viewToAdd];
    
    // Добавляем Activity Indicator
    
    indicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    indicator.frame = CGRectMake(0.0, 0.0, 40.0, 40.0);
    indicator.center = viewToAdd.center;
    [viewToAdd addSubview:indicator];
    [indicator bringSubviewToFront:viewToAdd];
    [indicator startAnimating];
}

-(void)removeActivityIndicatorAndLoadingView{
    
    viewToAdd.hidden = YES;
    indicator.hidden = YES;
    self.detailScrollView.scrollEnabled = YES;
    viewToAdd = nil;
    indicator = nil;
}

#pragma mark - table view delegate



// Высота ячейки

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 100;
}



-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}

// Метод определяющий количество ячеек (соответствует количеству объектов массива objectsArray

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 2;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSLog(@"Called once? ");
    
    // Инициализация ячейки
    
    
    cell = [tableView dequeueReusableCellWithIdentifier:@"detailCell" forIndexPath:indexPath];
    
    
        NSLog(@"called with b00l");
        [cell.myImageView setImageWithURL:[NSURL URLWithString:[[self.detailDataArray objectAtIndex:indexPath.row +1]valueForKey:@"standardImage"]]];
        cell.titleLabel.text = [[self.detailDataArray objectAtIndex:indexPath.row +1]valueForKey:@"title"];
        cell.dateLabel.text = [[self.detailDataArray objectAtIndex:indexPath.row +1]valueForKey:@"created_at"];
        

    NSLog(@"First spotling %@", [[self.detailDataArray objectAtIndex:1]valueForKey:@"itemId"]);
    NSLog(@"Second spotling %@", [[self.detailDataArray objectAtIndex:2]valueForKey:@"itemId"]);

    
    return cell;
}








@end
