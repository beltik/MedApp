//
//  MainViewController.h
//  MedApp
//
//  Created by Necrosoft on 22/01/16.
//  Copyright © 2016 Necrosoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/* Главный контроллер */

@interface MainViewController : UITableViewController

/* Массив хранящий объекты новостей NewsParseer */

@property (nonatomic, strong) NSMutableArray *dataArray;

/* Параметры  */

@property (nonatomic, strong) NSDictionary *parameters;

@end
