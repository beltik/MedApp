//
//  HTTPClient.m
//  MadApp
//
//  Created by Necrosoft on 18/01/16.
//  Copyright © 2016 Necrosoft. All rights reserved.
//

#import "HTTPClient.h"
#import "AFNetworking.h"

/* Главный URL */

#define MAIN_URL @"http://medsolutions.uxp.ru/api/v1/"


@implementation HTTPClient

/* Общий метод для получения данных методом GET */

-(void)getNewsWithParameters:(NSDictionary *)parameters completion:(void (^)(id))completion{
    
    /* Кастомизация объекта AFHTTPRequestOperationManager */
    
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:[NSURL URLWithString:MAIN_URL]];
    
    /* Устанавливаем HTTP Header */
    
    [manager.requestSerializer setValue:@"secret_key" forHTTPHeaderField:@"API-KEY"];
    
    /* Главный GET метод, в которого мы передаем ХТТП метод и параметры. В случае успеха получаем дату */
    
    [manager GET:@"news" parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"JSON: %@", responseObject);
        
        completion(responseObject);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        
    }];
    
    
    
    
    
}

/*  Получение деталей о новости */

-(void)getDetailOfNewsWithID: (NSString*)itemID  completion:(void (^)(id))completion{
    
    /* Кастомизация объекта AFHTTPRequestOperationManager */
    
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:[NSURL URLWithString:MAIN_URL]];
    
    /* Устанавливаем HTTP Header */
    
    [manager.requestSerializer setValue:@"secret_key" forHTTPHeaderField:@"API-KEY"];
    
    /* Главный GET метод, здесь параметры равны nil, и нужный нам id мы прописываем в хттп методе */
    
    [manager GET:[NSString stringWithFormat:@"news/%@", itemID] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSLog(@"JSON: %@", responseObject);
        
        completion(responseObject);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        
    }];
    
}















@end
